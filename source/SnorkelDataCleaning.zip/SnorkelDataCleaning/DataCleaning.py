import glob
import pandas as pd
import json
import re
from sklearn.model_selection import train_test_split
from snorkel.labeling import labeling_function
from snorkel.labeling import PandasLFApplier
from snorkel.analysis import get_label_buckets
from snorkel.labeling import LFAnalysis

generate=True
firstRun=False
were_working_here=False
just_predict_on_unseen_data=True
if firstRun==True:
    file_names=glob.glob("/home/campero/Desktop/2013_camera_specs/*/*.json")
    df=None
    for item in file_names:
        components=item.split("/")
        path=components[5]+"/"+components[6]
        with open(item) as f:
            data = json.load(f)
            alt_dict=dict()
            alt_dict["spec_id"]=["\""+path+"\""]
            alt_dict["page_title"]=["\""+data["<page title>"]+"\""]
            d=""
            for k in data.keys():
                if k!="<page title>":
                    d+=k+": "+str(data[k])+" ; "
            alt_dict["dump"]=["\""+d+"\""]
            if df is None:
                df=pd.DataFrame.from_dict(alt_dict)
            else:
                df2 = pd.DataFrame.from_dict(alt_dict)
                df=df.append(df2)
    df.to_csv(r'./all_data.csv', index=False, header=True)
    df= df.sample(3500, random_state=2)
    df.to_csv(r'./sample_data.csv', index=False, header=True)
elif generate:
    df=pd.read_csv('./sample_data.csv')
    df=df.sample(frac=1)
    train, test = train_test_split(df, test_size=0.99)
    train.to_pickle("./train.pkl")
    test.to_pickle("./test.pkl")
elif not generate:
    train = pd.read_pickle("./train.pkl")
    test = pd.read_pickle("./test.pkl")

@labeling_function()
def case_or_bag(x):#wifi was there as a stopping criteria
    return 0 if (bool([ele for ele in ["diving case", "case holder", "tool case", "flight case", "lenses case", "cameras case", "silicon case", "white case", "flip case", "housing case", "hard back case", "cover case", "case bag", "monopod", "tripod", "eva", "accessory", "waterproof case", "metal case", "android", "contact lens", "sleeve case", "silicone case", "camera case", "buy camera bag", "camera bag", "bag case", "buy case", "lense case", "lens case", "fashionable", "hard case", "backpack", "neopren", "case bag", "pouch", "protective case", "gopro case", "travel case", "plastic case", "pc case", "gps phone", "carrying case", "eva camera case", "shoulder bag", "ir case for ip camera", "camera housing"] if (ele in x.page_title.lower())]) and (not ("sports camera" in x.page_title.lower() or " MP" in x.page_title or "nikon digital camera coolpix" in x.page_title.lower() or "ip camera" in x.page_title.lower() or "hidden camera" in x.page_title.lower() or "spy camera" in x.page_title.lower() or "accessory bundle" in x.page_title.lower() or "accessory package" in x.page_title.lower() or "accessory kit" in x.page_title.lower() or " w " in x.page_title.lower() or (("camera with" in x.page_title.lower() or re.match(".*camera\s(?!bag|housing|case).*\swith.*", x.page_title.lower())!=None) and (not "with camera with" in x.page_title.lower())) or "metal case" in x.page_title.lower() or "rearview camera" in x.page_title.lower() or "moving camera" in x.page_title.lower() or "car camera" in x.page_title.lower() or "surveillance" in x.page_title.lower() or "cctv" in x.page_title.lower() or (" hd " in x.page_title.lower() and not "gopro hd" in x.page_title.lower()) or "inspection" in x.page_title.lower())) and (not ("megapixel" in x.dump.lower() or "mega pixel" in x.dump.lower() or "mega-pixel" in x.dump.lower() or "bundled_items" in x.dump.lower() or "bundled items" in x.dump.lower() or ("digital slr" in x.dump.lower() and (not "digital slr camera case" in x.dump.lower())) or "video" in x.dump.lower() or "resolution" in x.dump.lower())))\
    else -1#(1 if ("megapixel" in x.dump.lower() and not ("android" in x.page_title.lower()) and not ("gender" in x.dump.lower())) else
    #1 if (
    #"cctv" in x.page_title.lower() or "bullet" in x.page_title.lower() or "outdoor camera" in x.page_title.lower() or "endoscope" in x.page_title.lower() or "body" in x.page_title.lower() or "wireless" in x.page_title.lower()) else -1)


#tv in title and not cctv or ccd or security or surveillance or bullet in title
@labeling_function()
def tv(x):
    return 0 if ("fishfinder" in x.page_title.lower() or "memory concentration" in x.page_title.lower() or "edtv" in x.page_title.lower() or "tv " in x.page_title.lower() or "television" in x.page_title.lower() or ("led display" in x.page_title.lower() and "speakers" in x.dump.lower())) and not ("cctv" in x.page_title.lower() or "ccd" in x.page_title.lower() or "surveilance" in x.page_title.lower() or "android" in x.page_title.lower() or "security camera" in x.page_title.lower() or "ip camera" in x.page_title.lower() or "internet camera" in x.page_title.lower()) else -1 # I removed security


@labeling_function()
def battery(x):#Maybe better: re.match(".*(with|\sw\s).*\sbattery.*", x.page_title.lower())!=None
    return 0 if ("battery kit" in x.page_title.lower() or "batter" in x.page_title.lower() or "power bank" in x.page_title.lower()) and not ("battery recording" in x.page_title.lower() or "battery powered" in x.page_title.lower() or "battery operated" in x.page_title.lower() or "security" in x.page_title.lower() or "bundle" in x.page_title.lower() or "robot" in x.page_title.lower() or "wifi" in x.page_title.lower() or "body" in x.page_title.lower() or "with" in x.page_title.lower() or " w " in x.page_title.lower()) and not ("megapixel" in x.dump.lower() or "bundled items" in x.dump.lower() or "digital slr" in x.dump.lower() or "model: " in x.dump.lower() or "usb" in x.dump.lower() or "display" in x.dump.lower()) else -1 #

@labeling_function()
def flash_kit(x):
    return 0 if ("flash kit" in x.page_title.lower() and not ("with" in x.page_title.lower() or "w/" in x.page_title.lower())) else -1

@labeling_function()
def brands(x):#To dos, improve use of brands...
    return 1 if (bool([ele for ele in ["fujifilm finepix", "nikon s", "ricoh h", "powershot", "coolpix", "panasonic dmc", "ip camera", "canon ixus", "fuji digital", "web cam", "konica", "vivitar", "hikivision", "cyber-shot", "cyber shot", "easyshare", "power series", "panasonic lumix", "olympus", "sony a"] if (ele in x.page_title.lower())]) and not ("case for ip camera" in x.page_title.lower())) else -1

@labeling_function()
def shoes(x):
    return 0 if ("shoes" in x.page_title.lower() or "baseball hat" in x.page_title.lower() or "mp3 player" in x.page_title.lower() or "gripster" in x.page_title.lower()) \
    else -1

@labeling_function()
def mount(x):
    return 0 if (("mount" in x.page_title.lower() or "q-mount" in x.page_title.lower())  and ("lens" in x.page_title.lower() or "swivel" in x.page_title.lower()) and not (" w " in x.page_title.lower() or "with" in x.page_title.lower() or "camera" in x.page_title.lower())) else (0 if "flash" in x.page_title.lower() and (not ("camera" in x.page_title.lower())) and (not (" w " in x.page_title.lower())) and (not ("recorder" in x.page_title.lower())) and (not ("camcorder" in x.page_title.lower())) and (not("megapixel" in x.dump.lower())) else -1)

@labeling_function()
def filters(x):
    return 0 if (("filters" in x.page_title.lower() or "light meter" in x.page_title.lower()) and not "bundled items" in x.dump.lower()) else (0 if "bundled items: accessory bundle" in x.dump.lower() else -1)

@labeling_function()
def lenses(x):
    return 0 if ("lens hood kit" in x.page_title.lower() or "lenses" in x.page_title.lower() or "lens" in x.page_title.lower()) and (not ("camera" in x.page_title.lower()) and not ("megapixel" in x.dump.lower()) and not ("memory" in x.dump.lower()) and ("lens mount" in x.dump.lower())) else -1

#@labeling_function()
#def ones(x):
#    return 1
lfs = [case_or_bag, tv, shoes, battery, flash_kit, mount, filters, lenses]  # , brands]#, megapixel]
applier = PandasLFApplier(lfs=lfs)
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', -1)

if not firstRun and were_working_here:
    #print(train[["label", "spec_id", "page_title", "dump"]].sample(100, random_state=2))
    L_train = applier.apply(df=train)
    L_test = applier.apply(df=test)
    Y_test = test.label.values

    #print(train.iloc[L_train[:, 0] == 0])

    #print(train.iloc[L_train[:, 6] == 0])

    """
    print(train.iloc[L_train[:, 0] == 1].sample(20, random_state=1))
    
    #print(train.iloc[L_train[:, 2] == 1][["label","page_title"]])
    
    print(train.iloc[L_train[:, 1] == 0].sample(10, random_state=1))

    print(train.iloc[L_train[:, 2] == 1].sample(2, random_state=1))

    print(train.iloc[L_train[:, 3] == 0].sample(2, random_state=1))

    print(train.iloc[L_train[:, 4] == 0].sample(2, random_state=1))

    print(train.iloc[L_train[:, 5] == 0].sample(2, random_state=1))

    print(train.iloc[L_train[:, 6] == 1].sample(2, random_state=1))

    print(train.iloc[L_train[:, 7] == 0].sample(2, random_state=1))

    print(train.iloc[L_train[:, 8] == 0].sample(2, random_state=1))

    print(train.iloc[L_train[:, 9] == 0].sample(2, random_state=1))

    """
    #print(train.iloc[L_train[:, 5] == 0].sample(5, random_state=1))
    #buckets = get_label_buckets(L_train[:, 0], L_train[:, 1])
    #print(train.iloc[buckets[(-1, 0)]].sample(10, random_state=1))

    #print(train.iloc[L_train[:, 7] == 0].sample(5, random_state=1))

    print(LFAnalysis(L=L_test, lfs=lfs).lf_summary())
    #exit()
    from snorkel.labeling import MajorityLabelVoter

    majority_model = MajorityLabelVoter()
    preds_train = majority_model.predict(L=L_train)


    # %%
    #preds_train
    one_count=0
    zero_count=0
    abstain_count=0
#    for i in range(0, len(preds_train)):
#        if preds_train[i]==-1:
#            print(train.loc[[i]]["page_title"])

    # %% [markdown]
    # However, as we can see from the summary statistics of our LFs in the previous section, they have varying properties and should not be treated identically. In addition to having varied accuracies and coverages, LFs may be correlated, resulting in certain signals being overrepresented in a majority-vote-based model. To handle these issues appropriately, we will instead use a more sophisticated Snorkel `LabelModel` to combine the outputs of the LFs.
    #
    # This model will ultimately produce a single set of noise-aware training labels, which are probabilistic or confidence-weighted labels. We will then use these labels to train a classifier for our task. For more technical details of this overall approach, see our [NeurIPS 2016](https://arxiv.org/abs/1605.07723) and [AAAI 2019](https://arxiv.org/abs/1810.02840) papers. For more info on the API, see the [`LabelModel` documentation](https://snorkel.readthedocs.io/en/master/packages/_autosummary/labeling/snorkel.labeling.LabelModel.html#snorkel.labeling.LabelModel).
    #
    # Note that no gold labels are used during the training process.
    # The only information we need is the label matrix, which contains the output of the LFs on our training set.
    # The `LabelModel` is able to learn weights for the labeling functions using only the label matrix as input.
    # We also specify the `cardinality`, or number of classes.

    # %% {"tags": ["md-exclude-output"]}
    from snorkel.labeling import LabelModel

    label_model = LabelModel(cardinality=2, verbose=True)
    label_model.fit(L_train=L_train, n_epochs=500, log_freq=100, seed=123)

    # %%
    print("TEST1")
    majority_preds=majority_model.predict(L=L_test, tie_break_policy="ones")#Y=Y_test,
    #print(majority_preds)
    majority_acc = majority_model.score(L=L_test, Y=Y_test, tie_break_policy="ones")[
        "accuracy"
    ]

    print(f"{'Majority Vote Accuracy:':<25} {majority_acc * 100:.1f}%")
    cases=set()
    n = int(input("Enter number of elements : "))
    for i in range(0, n):
        ele = int(input())
        cases.add(ele)  # adding the element
    print(cases)
    counter=0
    for index, row in test.iterrows():
        if counter in cases:
            print(row)
            print("PREDICTION: "+str(majority_preds[counter]))
        counter+=1
    """
    print("DONT PAY ATTENTION TO THESE")
    label_model_acc = label_model.score(L=L_test, Y=Y_test, tie_break_policy="random")[
        "accuracy"
    ]
    print(f"{'Label Model Accuracy:':<25} {label_model_acc * 100:.1f}%")


    # %% [markdown]
    # The majority vote model or more sophisticated `LabelModel` could in principle be used directly as a classifier if the outputs of our labeling functions were made available at test time.
    # However, these models (i.e. these re-weighted combinations of our labeling function's votes) will abstain on the data points that our labeling functions don't cover (and additionally, may require slow or unavailable features to execute at test time).
    # In the next section, we will instead use the outputs of the `LabelModel` as training labels to train a discriminative classifier **which can generalize beyond the labeling function outputs** to see if we can improve performance further.
    # This classifier will also only need the text of the comment to make predictions, making it much more suitable for inference over unseen comments.
    # For more information on the properties of the label model, see the [Snorkel documentation](https://snorkel.readthedocs.io/en/master/packages/_autosummary/labeling/snorkel.labeling.LabelModel.html#snorkel.labeling.LabelModel).

    # %% [markdown] {"tags": ["md-exclude"]}
    # Let's briefly confirm that the labels the `LabelModel` produces are indeed probabilistic in nature.
    # The following histogram shows the confidences we have that each data point has the label SPAM.
    # The points we are least certain about will have labels close to 0.5.

    # %% {"tags": ["md-exclude"]}
    import matplotlib.pyplot as plt
    def plot_probabilities_histogram(Y):
        plt.hist(Y, bins=10)
        plt.xlabel("Probability of SPAM")
        plt.ylabel("Number of data points")
        plt.show()


    probs_train = label_model.predict_proba(L=L_train)
    plot_probabilities_histogram(probs_train[:, 0])

    # %% [markdown]
    # ### Filtering out unlabeled data points

    # %% [markdown]
    # As we saw earlier, some of the data points in our `train` set received no labels from any of our LFs.
    # These data points convey no supervision signal and tend to hurt performance, so we filter them out before training using a
    # [built-in utility](https://snorkel.readthedocs.io/en/master/packages/_autosummary/labeling/snorkel.labeling.filter_unlabeled_dataframe.html#snorkel.labeling.filter_unlabeled_dataframe).

    # %%
    from snorkel.labeling import filter_unlabeled_dataframe

    df_train_filtered, probs_train_filtered = filter_unlabeled_dataframe(
        X=train, y=probs_train, L=L_train
    )

    # %% [markdown]
    # ## 5. Training a Classifier

    # %% [markdown]
    # In this final section of the tutorial, we'll use the probabilistic training labels we generated in the last section to train a classifier for our task.
    # **The output of the Snorkel `LabelModel` is just a set of labels which can be used with most popular libraries for performing supervised learning, such as TensorFlow, Keras, PyTorch, Scikit-Learn, Ludwig, and XGBoost.**
    # In this tutorial, we use the well-known library [Scikit-Learn](https://scikit-learn.org).
    # **Note that typically, Snorkel is used (and really shines!) with much more complex, training data-hungry models, but we will use Logistic Regression here for simplicity of exposition.**

    # %% [markdown]
    # ### Featurization

    # %% [markdown]
    # For simplicity and speed, we use a simple "bag of n-grams" feature representation: each data point is represented by a one-hot vector marking which words or 2-word combinations are present in the comment text.

    # %% {"tags": ["md-exclude-output"]}
    from sklearn.feature_extraction.text import CountVectorizer

    vectorizer = CountVectorizer(ngram_range=(1, 5))
    X_train = vectorizer.fit_transform(df_train_filtered.page_title.tolist())
    X_test = vectorizer.transform(test.page_title.tolist())

    # %% [markdown]
    # ### Scikit-Learn Classifier

    # %% [markdown]
    # As we saw in Section 4, the `LabelModel` outputs probabilistic (float) labels.
    # If the classifier we are training accepts target labels as floats, we can train on these labels directly (see describe the properties of this type of "noise-aware" loss in our [NeurIPS 2016 paper](https://arxiv.org/abs/1605.07723)).
    #
    # If we want to use a library or model that doesn't accept probabilistic labels (such as Scikit-Learn), we can instead replace each label distribution with the label of the class that has the maximum probability.
    # This can easily be done using the
    # [`probs_to_preds` helper method](https://snorkel.readthedocs.io/en/master/packages/_autosummary/utils/snorkel.utils.probs_to_preds.html#snorkel.utils.probs_to_preds).
    # We do note, however, that this transformation is lossy, as we no longer have values for our confidence in each label.

    # %%
    from snorkel.utils import probs_to_preds

    preds_train_filtered = probs_to_preds(probs=probs_train_filtered)

    # %% [markdown]
    # We then use these labels to train a classifier as usual.

    # %% {"tags": ["md-exclude-output"]}
    from sklearn.linear_model import LogisticRegression

    sklearn_model = LogisticRegression(C=1e3, solver="liblinear")
    sklearn_model.fit(X=X_train, y=preds_train_filtered)

    # %%
    print(f"Test Accuracy: {sklearn_model.score(X=X_test, y=Y_test) * 100:.1f}%")
    """
if not were_working_here and just_predict_on_unseen_data:
    all_data = pd.read_csv("./all_data.csv")
    L_all_data = applier.apply(df=all_data)

    from snorkel.labeling import MajorityLabelVoter
    majority_model = MajorityLabelVoter()
    majority_preds = majority_model.predict(L=L_all_data, tie_break_policy="ones")

    #all_data=all_data.drop(['page_title', 'dump'], axis=1)
    all_data['is_prod'] = majority_preds
    all_data = all_data[all_data.is_prod.eq(0)]
    all_data.to_csv(r'./non_products.csv', index=False, header=True)
    non_products=0
    for item in majority_preds:
        if item==0:
            non_products+=1
    print("We found (nonproducts) "+str(non_products))
    print("Out of: "+str(len(majority_preds)))